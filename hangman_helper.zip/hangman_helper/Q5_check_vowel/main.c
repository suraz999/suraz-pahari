#include <stdio.h>

int main()
{
    char vowel []={'a','e','i','o','u'};
    int z=strlen(vowel);
    char word;
   int check=1;

    printf("enter the character:");
    scanf("%c",&word);
    for( int i=0;i<z;i++){
        if (word==vowel[i]){
            check++;
        }
    }
     printf("%d\n",check);
}
