
#include <stdio.h>

int main()
{
    char alphabhet []={"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOOQRSTVWVXYZ"};
    int z=strlen(alphabhet);
    char word;
    int check=1;

    printf("enter the character:");
    scanf("%c",&word);
    for( int i=0;i<z;i++){
        if (word!=alphabhet[i]){
            check++;}}
    if(check==1){
           printf("This is an invalid character\n");
        }
else{
     printf("This is valid\n");
}}

