#include <stdio.h>

int main()
{
    char secret_word[] = "apple";
    char guessed;

    printf("Guess the character:");
    scanf("%c", &guessed);
    int check = 0;

    for(int i=0; i<5; i++){
        if(secret_word[i] == guessed){
            check++;
        }
    }

    if(check > 0){
        printf("1\n");
    }else{
        printf("0\n");
    }
    return 0;
}
