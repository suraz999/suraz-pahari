 #include <stdio.h>

int main()
{
    char secret_word[]="apple";
    char guess_word[]={'e','i','k','p','r','s'};
    int z=strlen(secret_word);
    char display_word[z];
    for(int i=0;i<z;i++){
        display_word[i]='_';
      for (int j=0;j<z;j++){
          if (secret_word[i]==guess_word[j]){
              display_word[i]=guess_word[j];
          }
      }}
      for (int a=0;a<z;a++){
          printf("%c\t",display_word[a]);
      }
      printf("\n");
    }
