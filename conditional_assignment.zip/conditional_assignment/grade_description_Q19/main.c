#include <stdio.h>

int main()
{
   char grade;
   printf("enter the grade that you have obtained:");
   scanf("%c",&grade);
   if (grade=='E'){
       printf("EXCELLENT\n");
   }
   else if (grade=='V'){
    printf("VERY GOOD\n");
   }
   else if (grade=='G'){
       printf("GOOD\n");

   }
   else if(grade=='A'){
       printf("AVERAGE\n");
   }
   else if (grade=='A'){
       printf("FAIL\n");   }

   else {
       printf("Inalid garde\n");
   }

    return 0;
}
