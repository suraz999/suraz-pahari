#include <stdio.h>

int main()
{
    int num;
    printf("Enter the number(1-7):");
    scanf("%d",&num);
    if(num==1){
       printf("day %d is sunday\n",num);
    }
    else if(num==2){
        printf("day %d is monday\n",num);
    }
    else if(num==3){
         printf("day %d is tuessday\n",num);
    }
    else if(num==4){
        printf("day %d id wednesday\n",num);
    }
    else if (num==5){
        printf("day %d is thrusday\n",num);
    }
    else if (num==6){
        printf("day %d is friday\n",num);
    }
    else if (num==7){
            printf("day %d is saturday\n",num);
    }
    return 0;
}
