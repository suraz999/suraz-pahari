#include <stdio.h>

int main()
{
    int sideA,sideB,sideC;
    printf("Enter the three lengths of the triangle\n");
    printf("i:");
    scanf("%d",&sideA);
    printf("ii:");
    scanf("%d",&sideB);
    printf("iii:");
    scanf("%d",&sideC);


    if (sideA>sideB+sidec||sideB>sideA+sideC||sideC>sideB+sideA){
        printf("These length can form triangle\n");
    }
    else{
        printf("These length cannot form the triangle\n");
    }
    return 0;
}
