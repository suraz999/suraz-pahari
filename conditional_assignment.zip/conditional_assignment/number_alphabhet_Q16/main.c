#include <stdio.h>

int main()
{
    char character;
    printf("enter any character:");
    scanf("%c",&character);
    if ((character>='a'&&character<='z')||(character>='A'&&character<='Z')){
        printf("The character enter by you '%c'is alphabhet\n",character);
    }
    else if (character>='0'&&character<='9') {

        printf("The character enter by you '%c'is digit\n",character);


    }
\
    else {
        printf("The character enter by you '%c' is special chaaracter\n",character);
    }
    return 0;
}
