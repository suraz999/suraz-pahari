#include <stdio.h>

int main()
{
   int temp;
   printf("enter the temperature in degree celcius:");
   scanf("%d",&temp);

    if(temp<0){
       printf("It's a freezing weather\n" );
   }

   else if(temp>=0&&temp<10){
        printf("It's very cold weather\n");
    }
   else if (temp>=10&&temp<20){
        printf("It's cold weather \n");
    }
    else if (temp>=20&&temp<30){
        printf("It's normal tenperature\n");
    }
    else if(temp>=30&&temp<40){
        printf("It's hot weather\n");
    }
    else if (temp>=40){
        printf("It's very hot\n");
    }
    return 0;
}
