#include <stdio.h>

int main()
{
   int option;
   float area;
   printf("CHOOSE THE GEOMETRICAL OF WHICH YOU WANT AREA \n");
   printf("1.square\n");
   printf("2.triangle\n");
   printf("3.circle\n");
   printf("4.quit\n");


   printf("choose option:\n");
   scanf("%d",&option);

   if (option==1){
    printf("You have choosen the square\n");
    printf("Enter the length of the square:\n");
    float length;
    scanf("%f",&  length);
    area=length*length;
    printf("The area of the square is %f sq.metre\n3",area);
   }
   if (option==2){
       printf("You have choosen the triangle \n");
       float height,base;
       printf("Enter the base of the triangle:\n");
       scanf("%f",&base);
       printf("Enter the height of the triangle:\n ");
       scanf("%f",&height);
       area=(base*height)/2.0;
       printf("The area of the triangle is %f sq.metre\n",area);
      }

  else if (option==3){
       printf("You have choosen the circle\n");
       float pie=3.142,radius;
       printf("Enter the radius of the circle:\n");
       scanf("%f",&radius);
       area=pie *radius *radius;
       printf("The area of the circle is %f sq.metre\n",area);
   }


if (option==4){
    printf("Press enter again to quit\n");

}
if (option>4){
    printf("invalid option\n");
}




    return 0;
}
