#include <stdio.h>

int main()
{
    int marks_phy,marks_chem,marks_maths,marks_total;
    printf("enter the marks in physics:");
    scanf("%d",&marks_phy);
    printf("enter the marks in maths:");
    scanf("%d",&marks_maths);
    printf("enter the  marks in chemistry:");
    scanf("%d",&marks_chem);

    marks_total=marks_phy+marks_chem+marks_maths;

    if(marks_maths>=65&&marks_chem>=50&&marks_phy>=55&&marks_total==180&&
        marks_maths+marks_phy||marks_chem>=140    ){
        printf("welcome ,you can get addmission here\n");



    }
    else {
        printf("sorry,you cannot get addmission here\n");
    }
    return 0;
}
