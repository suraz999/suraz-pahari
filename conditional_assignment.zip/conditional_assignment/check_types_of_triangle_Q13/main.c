#include <stdio.h>

int main()
{
    int a,b,c ;
    int i=0;
     printf("enter the sidde of triangle (a,b,c)\n");
     printf("a:");
     scanf("%d",&a);
     printf("b:");
     scanf("%d",&b);
     printf("c:");
     scanf("%d",&c);

     if (b+c>a||a+c>b||a+b>c){
         printf("Triangle cannot be formed by this given sides\n");
         i=1;
     }

     if (a==b&&b==c&&i==0){
        printf("The triangle of sides %d,%d,%d is equilateral\n",a,b,c);

     }
      else if((a!=b||a!=c)&&i==0){
       printf("The triangle of sides %d,%d,%d is scalence\n",a,b,c);
     }
     else if (a==b||b==c||a==c||i==0) {
         printf("The triangle of sides %d,%d,%d is isoceles\n",a,b,c);

     }
    return 0;
}
