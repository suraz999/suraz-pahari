#include <stdio.h>

int main()
{
    int int1,int2;
     printf("Enter the first integer:");
     scanf("%d",&int1);
     printf("Enter the second integer:");
     scanf("%d",&int2);

     if (int1==int2){
         printf("These two integers are equal\n");
     }
     else{
         printf("These two integer are not equal\n");
     }
    return 0;
}
