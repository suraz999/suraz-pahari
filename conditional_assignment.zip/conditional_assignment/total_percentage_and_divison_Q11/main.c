#include <stdio.h>

int main()
{

    char name[20];
    int roll_no;
    int marks_maths,marks_physics,marks_english;
    printf("enter your name:");
    scanf ("%s",&name);
    printf("enter the roll no:");
    scanf("%d",&roll_no);

    printf("enter the marks obatined out of 100 in:\n");
    printf ("physics:");\
    scanf("%d",&marks_physics);
    printf("maths :");
    scanf("%d",&marks_maths);
    printf("english:");
    scanf("%d",&marks_english);


    double percentage;
    percentage=((marks_maths+marks_english+marks_physics)*100.00)*(1.00/300.00);

    printf("      RESULT        \n");
    printf("name :%s\n",name);
    printf("rol no:%d\n",roll_no);
    printf("obtained percentage is %f\n",percentage);


    if( percentage <40){
       printf("****failed*****\n");
    }
   else if (percentage>40&&percentage<50){
    printf("division=third\n");
    }
    else if (percentage>=50&&percentage<60) {
      printf("division =second\n");
    }
    else if (percentage>=60&&percentage<80) {
      printf("division=distintion\n");
    }
     else if(percentage>80){
        printf("division=distintion\n");
    }
    return 0;
}
