#include <stdio.h>

int main()
{
    int age;
    printf(" enter your age:");
    scanf("%d",&age);
    if (age<18){
     printf("you are  not eligible for casting  vote\n");
    }
     else{
        printf("you are eligible for casting vote\n");

    }

    return 0;
}
