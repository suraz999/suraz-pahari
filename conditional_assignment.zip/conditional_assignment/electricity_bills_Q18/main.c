#include <stdio.h>

int main()
{
    char name [25];
    int id_no;
    float unit;

   printf("enter your name(firstname_lastname):");
   scanf("%s",name);
   printf("enter your ID no:");
   scanf("%d",&id_no);
   printf("Enter the total unit of the electricity:");
   scanf("%f",&unit);

    float  cost=0.00;
    float total_cost=0.00;
    float  cost1=199.00*1.20;
    float cost2=199.00*1.5;
    float cost3=199.00*1.80;


     if (unit<200.00){
        cost =unit*1.2;
     }
    else  if (unit>200&&unit<400){
           cost=cost1+(unit-199)*1.50;

     }
    else  if(unit>400&&unit<600 ){
          cost=cost1+cost2+(unit-199-199)*1.80;

     }
    else if (unit>=600){
          cost=cost1+cost2+cost3+(unit-199-199-199)*2;
     }

     total_cost=cost;

   if ( cost>400){
       float tax=15.00/100.0*cost;
        total_cost=tax+cost;
    }
    else if (cost<100){
        total_cost=100;


     }
 printf("\nname :%s\n",name);
 printf("id no:%d\n",id_no);
printf("The total electricity cost is Rs %f\n",total_cost);


return 0 ;
}
