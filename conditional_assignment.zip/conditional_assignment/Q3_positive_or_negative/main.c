#include <stdio.h>

int main()
{
  int number;
  printf("enter the number:");
  scanf("%d",&number);

  if(number<0){
   printf("the given number is negative\n");
  }
   else{
   printf("the given number is positive\n");

  }

}
