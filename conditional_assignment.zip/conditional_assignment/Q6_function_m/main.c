#include <stdio.h>

int main()
{
    int  value;
    printf("enter the value of m:");
    scanf("%d",&value);
    if(value>0){
       printf("the value of m is 1\n");
    }
    else if (value==0){
        printf("the value of m is 0\n");

    }
   else if (value<0){
        printf("the value of m is -1\n");
    }

    return 0;
}
