#include <stdio.h>
#include <math.h>
int main()
{
    int a,b,c;
    double root_1,root_2;
    printf(("enter the value of "));
    printf("a:");
    scanf("%d",&a);
    printf("b:");
    scanf("%d",&b);
    printf("c:");
    scanf("%d",&c);


    if (a==0){
        printf("the value a cannot be zero");

    }
   int d=b*b-4*a*c;
   double sq=sqrt(abs(d));

   if (d>0){
       root_1=(double)((-b-sq)/-2*a);
       root_2=(double)((-b+sq)/2*a);
     printf("roots are;\n %d\n %d\n",root_1,root_2);


   }
   else if (d==0){
   root_1=(double)(-b/2*a);
   root_2=root_1;
   printf("roots are\n %d\n %d\n",root_1,root_2);
   }

   else if (d<0){
      printf("it has two imaginnary roots\n");


 }

     return 0;
}



