#include <stdio.h>

int main()
{
 int angleA,angleB,angleC;
 printf("enter the all three angles of the traingle\n");
 printf("A:");
 scanf("%d",&angleA);
 printf("B:");
 scanf("%d",&angleB);
 printf("C:");
 scanf("%d",&angleC);

 if (angleA+angleB+angleC==180&&(angleA!=0||angleB!=0||angleC!=0)){
     printf("These given three angles can form triangle.\n");
 }
 else {

     printf("These given three angles cannot form the triangle.\n");
 }



    return 0;
}
