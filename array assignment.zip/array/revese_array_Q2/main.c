#include <stdio.h>

int main()
{


        int elements;
        printf("Enter the total number of elements in array:");
        scanf("%d", &elements);

        int array[elements];
        printf("enter the elements in order\n");
        for(int i=0;i<elements;i++){
            printf(":");
            scanf("%d",&array[i]);
        }

        for( int i=elements-1;i>=0;i--){

            printf("%d\t",array[i]);
        }
    printf("\n");
        return 0;
    }


