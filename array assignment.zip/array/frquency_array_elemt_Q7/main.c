#include <stdio.h>

int main()
{
    int array[10] = {1,2,2,3,3,4,4,5,6,7};
    int temporary;
    int frequency[10] = {};

    for(int i=0; i<=9; i++){
        frequency[i] = -1;
    }

    for(int i=0; i<=9; i++){
        temporary = 1;
        for(int j=i+1; j<=9; j++){
            if(array[i] == array[j]){
                temporary++;
                frequency[j] = 0;
            }
        }

        if(frequency[i] != 0){
            frequency[i] = temporary;
        }
    }

    for(int i=0; i<=9; i++){
        if(frequency[i] != 0){
           printf("%d occurs %d times\n", array[i], frequency[i]);
        }

    }
    return 0;
}
