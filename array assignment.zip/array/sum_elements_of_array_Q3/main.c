#include <stdio.h>

int main()
{
    int array[10] = {1,2,3,4,5,6,7,8,9,10};
    int sum;

   for(int i=0; i <=5; i++){
          sum += array[i];
   }
     printf("the sum of all elements of array %d\n", sum);
    return 0;
}
