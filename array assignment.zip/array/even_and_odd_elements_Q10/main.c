#include <stdio.h>

int main()
{
    int array[6] = {2,-1,3,23,8,6};
        int even[6] = {};
        int odd[6] = {};

        int j = 0;
        for(int i=0; i<=9; i++){
            if(array[i]%2 == 0){
                even[j] = array[i];
                j++;

            }else{
                odd[j] = array[i];
                j++;
            }

        }

        printf("even elements: \n");
        for(int i =0; i<=5; i++){
            if(even[i] != 0){
                printf("%d\t",even[i]);
            }
        }

        printf("\n");

        printf(" odd elements: \n");
        for(int i =0; i<=5; i++){
            if(odd[i] != 0){
                printf("%d\t",odd[i]);
            }
        }

        printf("\n");

        return 0;
    }
