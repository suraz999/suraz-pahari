#include <stdio.h>

int main()
{int array[6] = {2,-1,3,23,8,6};
    int max[6] = {};
    int min[6] = {};

    for(int i=0; i<6; i++){
        max[i] = array[i];
    }

    for(int i=0; i<6; i++){
        min[i] = array[i];
    }

    for(int i=1; i<6; i++){
        if(max[0] < max[i]){
            max[0] = max[i];
        }
    }

    for(int i=1; i<6; i++){
        if(min[0] > min[i]){
            min[0] = min[i];
        }
    }

    printf("the maximum element is %d \n", max[0]);
    printf("the minimum element is %d\n", min[0]);

    return 0;
}
