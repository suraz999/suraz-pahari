#include <stdio.h>

int main()
{

    int array[7] = {1,1,2,2,3,4,4};
    int temporary = 0;
    int totalDups = 0;
    int i, j;

    for(i=0; i<=6; i++){
        temporary = 0;
        for(j=i+1; j<=6; j++){
            if(array[i] == array[j]){
                temporary++;
            }
        }

        if(temporary > 0){
            totalDups++;
        }
    }


    printf("Total duplicate elements are: %d\n", totalDups);
    return 0;

}
