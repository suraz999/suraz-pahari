#include <stdio.h>

int main()
{
    int array[6] = {2,-1,3,23,8,6};
    int tohold;

    for(int i=0; i<=5; i++){
        for(int j=i+1; j<=5; j++){
            if(array[i] < array[j]){
                tohold = array[j];
                array[j] = array[i];
                array[i] = tohold;
            }
        }
    }

    printf("The second largest element is %d.\n", array[1]);
    return 0;
}
