#include <stdio.h>

int main()
{
    int i;
    for (i=0;i<3;i=i+1)
        printf("a\n");
        printf("b\n");
        printf("c\n");

}
