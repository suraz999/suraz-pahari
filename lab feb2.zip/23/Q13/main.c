#include <stdio.h>
#include <math.h>

int main(){
    int num, sum=0, last, backup;
    printf("Enter the number:");
    scanf("%d", &num);

    backup = num;

    while(num != 0){
        last = num%10;
        sum += last*last*last;
        num = num/10;
    }

    if(backup == sum){
     printf("%d is armstrong number.\n", backup);
    }else{
        printf("%d is not armstrong number.\n", backup);
    }

    return 0;
}
