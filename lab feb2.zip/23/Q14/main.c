#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{

    char password[50];
    int sum = 0;
    printf("Enter your password:");
    gets(password);

    int upper=0, lower=0, digit=0, special=0;

    if(strlen(password) < 6){
        printf("Password must be atleast 6+ password[i]aracters.\n");
        return 0;
    }

    for(int i=0; i<strlen(password); i++){

            if( islower(password[i]) ){
                if(lower >= 1){
                   continue;
                }
                 lower++;

            }

            if( isupper(password[i]) ){

                if(upper >= 1){
                    continue;
                }
                upper++;
            }

            if( isdigit(password[i]) ){

                if(digit >= 1){
                    continue;
                }
                digit++;
            }

            if(!(('a' <=  password[i] && password[i] <= 'z') || ('A' <=  password[i] && password[i] <= 'Z') || ('0' <=  password[i] && password[i] <= '9'))){
                if(special >= 1){
                    continue;
                }
                special++;

            }else{

            }

    }

    sum = lower+upper+digit+special;

    printf("%d", special);
    if(sum > 3){
        printf("Your password is strong and valid.");
    }else{
        printf("Your password is weak.");
    }

}
