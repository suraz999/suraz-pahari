#include <stdio.h>
int main()
{
  int num, temp;

  printf("Enter an integer in decimal number system\n");
  scanf("%d", &num);

  printf("Given num in binary number system is:\n");

  for (int i = 6; i >= 0; i--)
  {
    temp = num >> i;

    if (temp & 1)
      printf("1");
    else
      printf("0");
  }

  printf("\n");

  return 0;
}
