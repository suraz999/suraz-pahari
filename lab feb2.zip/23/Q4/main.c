#include <stdio.h>

int main()
{
    int x=3;
    if(x)
     printf("yes\n");
    else
      printf("no\n");
}
