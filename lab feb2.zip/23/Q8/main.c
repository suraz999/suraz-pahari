#include <stdio.h>

int main()
{
 float sum=0.00;
 printf("the integers are:");
 for  (int i=9;i<=300;i++){
     if (i%7==0&&i%63!=0){
         sum=sum+i;
         printf("%d\n",i);
     }
     else {
         sum=sum;
     }

 }
 printf("The sum is %f\n",sum);
}
