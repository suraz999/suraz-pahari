#include <stdio.h>


int main()
{
   int num;
   int sum=0;
   int remaining;
   printf("Enter the  integer:");
   scanf("%d",&num);

   while(num!=0){
       remaining=num%10;
       sum=sum+remaining;
       num=num/10;
   }
   printf("The sum of each digit of given integer is %d\n",sum);


}
