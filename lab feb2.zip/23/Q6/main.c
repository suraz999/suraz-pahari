#include <stdio.h>

int main()
{
    int a[5];
    for(int i;i<=5;i=i+1)
        a[i]=0;

}
