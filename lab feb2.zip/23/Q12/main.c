
#include <stdio.h>

int main()
{
    int number;
    int sum=0.0;
    int n=0;
    int maximum,minimum;
    printf("enter the first number:");
    scanf("%d",&number);
    int num1=number;
    int maxnumber=number;
    int minnumber=number;

   do  {
      //sum=sum+number;
        printf("enter the other  number:");
        scanf("%d",&number);


//        sum+=number;
//        n++;
       if (number>maxnumber){
           maximum=number;
           maxnumber=number;
       }
       if(number<minnumber){
           minimum=number;
           minnumber=number;

       }
       sum+=number;

       n++;


       }


    while(number<0);

    printf("the sum of the number is %d\n",sum+num1);
    printf("the average of the numbers is %d\n",(sum+num1)/n);
    printf("the maximum number is %d\n",maximum);
    printf("the minimum number is %d\n",minimum);

    return 0;
}
