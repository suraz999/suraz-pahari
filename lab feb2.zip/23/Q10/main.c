#include <stdio.h>
#include <math.h>

int main()
{
    double co_north1=27.7172,co_east1=85.3240;
    double co_north2=28.2096,co_east2=83.9856;
    double distance;
    double diff1=(co_north2-co_north1)*(co_north2-co_north1);
    double diff2=(co_east2-co_east1)*(co_east2-co_east1);
    distance=(sqrt(diff2+diff1));

    printf("%f\nR",distance);


}
