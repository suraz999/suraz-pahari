#include <stdio.h>

struct points{
    int x,y;
};

struct rectangle{
    struct points p1, p2, p3, p4;
};

struct square{
    struct points p1, p2, p3, p4;
};

struct circle{
    int radius;
    struct points centerpoint;
};

int main()
{
    struct rectangle r1 = {
        .p1={0,0},
        .p2={0,5},
        .p3={10,10},
        .p4={10,0}
    };  //same idea will be for squares

    struct circle c1 = {
        .radius = 5,
        .centerpoint = {0,0}
    };

    printf("Center coordiante of the circle is: (%d, %d) and the radius is %d\n", c1.centerpoint.x, c1.centerpoint.y,  c1.radius);
    return 0;
}
