#include <stdio.h>

//declaring a struct

struct coordinate{
  int x, y;
};

int main()
{
    struct coordinate points;

    printf("Enter x:");
    scanf("%i", &points.x);

    printf("Enter y:");
    scanf("%i", &points.y);



    printf("x is %i and y is %i\n", points.x, points.y);

    return 0;
}
