#include <stdio.h>

struct student{
    int id;
    char name[50];
    char address[50];
    char faculty[50];

    struct DOB{
        int day, month, year;
    }dob;
};

int main()
{
    struct student s[5]={
    {
        .id      = 1,
        .name    = "Dikshyant Adhikari",
        .address = "Lakeside, Pokhara",
        .faculty = "Software",
        .dob = {29, 05, 2000}
    },
    {},
    {},
    {},
    {}
    };


//    int id, day, month, year;
//    char name[191];
//    char address[191];
//    char faculty[191];
        char c;
        for(int i=1; i<3; i++){
            printf("Enter id: ");
            scanf("%d%c", &s[i].id, &c);

            printf("Enter name: ");
            gets(&s[i].name);

            printf("Enter address: ");
            gets(&s[i].address);

            printf("Enter faculty: ");
            gets(&s[i].faculty);

//            printf("Enter birth year: ");
//            scanf("%d", &s[i].year);

//            printf("Enter birth month: ");
//            scanf("%d", &s[i].month);

//            printf("Enter birth day: ");
//            scanf("%d", &s[i].day);
        }

        printf("Id\t Name\t\t\t Address\t\t\t Faculty\t\n");

        for(int i=0; i<3; i++){
            printf("%d\t %s\t %s\t\t %s\t\n", s[i].id, s[i].name, s[i].address, s[i].faculty);
        }



    return 0;
}
