#include <stdio.h>

struct triangle_t{
    struct point{
        int x,y;
    }p1,p2,p3;
};

int main()
{
    struct triangle_t triangle = {
        .p1={0,0},
        .p2={100,75},
        .p3={-60,80}
    };

    printf("The coordinate of the triangles are:\n");

    printf("(%d, %d), (%d, %d), (%d, %d)\n", triangle.p1.x, triangle.p1.y, triangle.p2.x, triangle.p2.y, triangle.p3.x, triangle.p3.y);
    return 0;
}
