#include <stdio.h>
#define N 4

struct student{
    char name[20];
    int eng;
    int math;
    int phys;
    float average;
};

static struct student data[]={
    {"Ram", 82, 72, 58},
    {"Hari", 77, 82, 79},
    {"Ashesh", 52, 62, 39},
    {"Aayush", 61, 82, 88}
};

char gradeCheck(int average){
    if(average >= 90){
        return 'S';
    }else if(average >= 80){
        return 'A';
    }else if(average >= 70){
        return 'B';
    }else if(average >= 60){
        return 'C';
    }else{
        return 'D';
    }
}

int main(void)
{
    int i;
    for(i=0; i<N; i++){
        float average = (double)(data[i].eng+data[i].math+data[i].phys)/3;
        printf("%7s: Eng = %3d Math = %3d Phys = %3d Average = %3f Grade = %c\n", data[i].name, data[i].eng, data[i].math, data[i].phys, average, gradeCheck(average));
    }
    return (0);
}
