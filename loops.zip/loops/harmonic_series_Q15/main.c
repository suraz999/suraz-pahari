#include <stdio.h>

int main()
{
    int n;
    printf("Enter the nth term:");
    scanf("%d", &n);
    float sum = 0;

    for(float i=1; i<=n; i++){
       sum += 1/i;
    }

    printf("The sum of %d harmonic series is: %f\n", n, sum);
    return 0;

}
