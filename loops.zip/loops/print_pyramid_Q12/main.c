#include <stdio.h>

int main()
{
    int height;

    printf("Enter the height:");
    scanf("%d", &height);

    int space = height;

    for(int i=0; i<height; i++){
        for(int j=0; j<=space; j++){
            printf(" ");
        }
        for(int k=0; k<=i; k++){
            printf("* ");
        }
        space--;
        printf("\n");
    }

    return 0;
}
