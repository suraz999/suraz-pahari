
#include <stdio.h>

int main()
{
    int n;
      printf("enter the nth term:");
      scanf("%d", &n);

      int number1=0, number2=1, number3;

      int i = 1;
      while(i <= n){
          printf("%d\t", number1);
          number3 = number1 + number2;
          number1 = number2;
          number2 = number3;
          i++;}
    return 0;
}
