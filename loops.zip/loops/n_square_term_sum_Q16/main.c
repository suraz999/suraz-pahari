#include <stdio.h>

int main()
{
    int number;
    int sum=0;
    printf("enter the no of the term for squaring:");
    scanf("%d",&number);
    for (int i=1;i<=number;i++){
        int n=i*i;
        sum=sum+n;
    printf("%d\t",n);}

    printf("the sum upto given term is %d",sum);

    return 0;
}
