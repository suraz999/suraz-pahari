#include <stdio.h>

int main()
{

    char asterik = '*';


    for(int i=1; i<=4; i++){
        for(int j=1; j<=i; j++){
            printf("%c\t", asterik);
        }
        printf("\n");
    }

    return 0;
}
