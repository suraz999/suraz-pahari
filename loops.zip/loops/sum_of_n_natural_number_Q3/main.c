#include <stdio.h>

int main()

{   int n;
    int sum;
    printf("enter the no of terms:");
    scanf("%d",&n);
    for(int i=0;i<(n+1);i++){
      sum=sum+i;
    }
    printf("the sum of natural number upto %d is %d\n",n,sum);
    return 0;
}
