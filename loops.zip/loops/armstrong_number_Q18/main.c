#include <stdio.h>

int main()
{
    int digit;
     for (digit=1;digit<1000;digit++){
     int d1 =digit/1000;
     int d2=(digit%1000)/100;
     int d3 =(digit%1000)%100/10;
     int d4=digit-(d1 *1000+d2 *100+d3 *10);


     if (d1*d1*d1+d2*d2*d2+d3*d3*d3+d4*d4*d4==digit){
         printf("%d\t",digit);
    }
     }


     return 0;
}
