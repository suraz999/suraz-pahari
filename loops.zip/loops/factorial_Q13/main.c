#include <stdio.h>

int main()
{   int number;
    printf("enter the number:");
    scanf("%d",&number);
    int factorial=1;
    for (int i=1;i<=number;i++){

        factorial=factorial*i;
    }
    printf("the factorial of %d is %d\n\n",number,factorial);
    return 0;
}
