#include <stdio.h>

int main()
{

    int numbers;
    int sum=0;
    int n=10;

    for( int i=1;i<=10;i++){
        printf( "enter the no %d:", i);
        scanf("%d",&numbers);
        sum=sum+numbers;
    }
    printf("sum is %d\n",sum);
    float average;
    average=(double) sum/n;
    printf("average is %f\n",average);

    return 0;
}
