#include <stdio.h>

int main()
{
   int sum;
   int i;
  for(i=1;i<11;i++){
       sum=sum+i;}
   printf("%d/n",sum);

    return 0;
}
