#include <stdio.h>

int main()
{
    int number;
    printf("enter any number:");
    scanf("%d",&number);
    int factor=0;
    for(int i=2;i<number;i++){
        if(number%i==0){
           factor++;
        }

    }
    if (factor>=1){
       printf("The  %d is composite number\n",number);

    }
    else{
        printf("The %d is prime number\n",number);
    }

  return 0;
}
