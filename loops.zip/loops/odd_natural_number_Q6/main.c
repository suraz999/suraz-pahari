#include <stdio.h>

int main()
{
    int number;
    printf("enter the n term :");
    scanf("%d",&number);
    int sum=0;
    for(int i=1;i<=number*2;i=i+2){
      printf("%d\n",i);
      sum=sum+i;
    }
    printf("the sum is %d\n",sum);

    return 0;
}
