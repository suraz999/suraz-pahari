#include <stdio.h>
#include <string.h>
#define MAX_SIZE 100

int main()
{
    char string[MAX_SIZE];
    int i, length, vowel, consonant;

    printf("Enter any string: ");
    gets(string);

    vowel = consonant = 0;
    length=strlen(string);

    for(i=0; i<length; i++)
    {
        if((string[i]>='a' && string[i]<='z') || (string[i]>='A' && string[i]<='Z'))
        {

            if(string[i] =='a' || string[i]=='e' || string[i]=='i' || string[i]=='o' || string[i]=='u' ||
               string[i] =='A' || string[i]=='E' || string[i]=='I' || string[i]=='O' || string[i]=='U'  )
                vowel++;
            else
                consonant++;
        }
    }

    printf("Total number of vowel = %d\n", vowel);
    printf("Total number of consonant = %d\n", consonant);

    return 0;
}
