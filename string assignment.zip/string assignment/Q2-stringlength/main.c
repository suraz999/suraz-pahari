#include <stdio.h>

int main()
{
    char string[100];
    int length,i,count=0;
    printf("enter a sentence:");
    gets(string);
    length=strlen(string);
    for (i=0;i<length;i++)
    {
        if(string[i]!=' ' )
        {
            continue;
        }
            else(count++);
        }
        printf("the total number of word is %d:",count+1);
    }
