#include <stdio.h>
#include <stdlib.h>

int main(){

    char line[81];
   gets(line);
   printf("the string you entered is :%s,line");

    return 0;
}
