#include <stdio.h>
#include <stdlib.h>
int main(){
char string[81];
gets(string);
printf("the string you want to enter is:%s",string);

}

